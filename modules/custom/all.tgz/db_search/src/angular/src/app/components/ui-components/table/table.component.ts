import { Component, OnChanges, Input, Output, EventEmitter, SimpleChanges, ElementRef, ViewChild } from '@angular/core';
import { enableResizableColumns } from './enableResizableColumns';

interface Header {
  label: string;
  key: string;
  sort?: 'asc' | 'desc' | null | undefined;
  tooltip?: string
}

@Component({
  selector: 'ui-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnChanges {

  @Input()
  headers: Header[];

  @Input()
  data: any;

  @Input()
  numResults: number;

  @Input()
  pageSizes = [50, 100, 150, 200, 250, 300];

  @Input()
  loading: boolean = true;

  @Output()
  sort: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  paginate: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('table') table;

  pageSize = this.pageSizes[0];
  pageNumber = 0;
  pagingModel: any;

  constructor() { }

  toggleSort(header: Header) {

    let toggledSort: 'asc' | 'desc' = header.sort === 'asc'
      ? 'desc'
      : 'asc';

    for (let h of this.headers)
      h.sort = null;

    header.sort = toggledSort;

    this.sort.emit({
      sort_column: header.key,
      sort_direction: header.sort
    })
  }

  emitPagination() {
    this.paginate.emit({
      page_size: this.pageSize,
      page_number: this.pageNumber
    });
  }

  getTotalPages(): number {
    return Math.ceil(this.numResults / this.pageSize) || 1;
  }

  setPageSize(size) {
    this.pageSize = +size;
    // If current page is out of range, set to last page
    const totalPages = this.getTotalPages();
    if (this.pageNumber > totalPages) {
      this.pageNumber = totalPages;
    }
    // If pageNumber is not set, default to 1
    if (!this.pageNumber || this.pageNumber < 1) {
      this.pageNumber = 1;
    }
    this.pagingModel = this.pageNumber;
    this.emitPagination();
  }

  setCurrentPage(event) {
    this.pageNumber = event.page;
    this.pagingModel = this.pageNumber;
    this.emitPagination();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['data'] && this.data && this.table && this.table.nativeElement) {
      window.setTimeout(e => {
        enableResizableColumns(this.table.nativeElement);
      }, 0);
    }
  }
}
